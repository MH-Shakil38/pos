<?php $__env->startSection('title', 'Login'); ?>

<?php $__env->startSection('form'); ?>

<?php if(session('status')): ?>
<div class="alert alert-primary" role="alert">
    <?php echo e(session('status')); ?>

</div>
<?php endif; ?>

<form action="<?php echo e(route('login')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <div class="form-group mb-3">
        <input type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id=" Email"
            placeholder="Email address" value="<?php echo e(old('email')); ?>" required autocomplete="email" name="email" autofocus>
        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <p class="text-danger"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="form-group mb-4">
        <input type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="Password"
            placeholder="Password" name="password" required autocomplete="current-password">
    </div>
    <div class="custom-control custom-checkbox text-left mb-4 mt-2">
        <input type="checkbox" class="custom-control-input" id="customCheck1" name="remember">
        <label class="custom-control-label" for="customCheck1">Save credentials.</label>
    </div>
    <button class="btn btn-block btn-primary mb-4">Signin</button>
</form>
<hr>
<p class="mb-2 text-muted">
    Forgot password?
    <a href="<?php echo e(route('password.request')); ?>" class="f-w-400">Reset</a>
</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\portfolio-laravel-pos\resources\views/auth/login.blade.php ENDPATH**/ ?>