<?php $__env->startSection('title','Add a new batch'); ?>

<?php $__env->startPush('css'); ?>
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<style>
    .select2-container--default .select2-selection--single {
        background-color: #fff;
        border: 2px solid rgba(0, 0, 0, 0.15);
        border-radius: 0px;
        height: 49px;
    }

    .select2-container--default .select2-selection--single .select2-selection__rendered {
        color: #444;
        line-height: 45px;
        margin-left: 10px;
    }

    .select2-container--default .select2-selection--single .select2-selection__arrow {
        top: 10px;
        right: 5px;
    }
</style>
<script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
<?php $__env->stopPush(); ?>


<?php $__env->startSection('main'); ?>
<form method="POST" action="<?php echo e(route('batches.store')); ?>">
    <?php echo csrf_field(); ?>
    <div class="row"
        x-effect="total_purchase_cost = quantity * purchase_price, due_amount = total_purchase_cost - paid_amount, paid_amount = total_purchase_cost - due_amount"
        x-data="{ 
        quantity: 0, 
        purchase_price: 0, 
        total_purchase_cost: 0,
        status: '',
        paid: false,
        paid_amount: 0,
        due_amount: 0,
    }">
        <div class="col-8">
            <div class="card">
                <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <?php endif; ?>
                <div class="card-header">
                    <h5>Add a new batch of product</h5>
                </div>
                <div class="card-body">
                    <div class="form-group">
                        <label for="products">Select A Product</label>
                        <select class="form-control js-example-basic-single" name="product_id" id="products">
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($product->id); ?>"><?php echo e($product->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="exampleInputEmail1">Quantity <small class="text-info">[Piece]</small></label>
                        <input x-model.number="quantity" type="number" class="form-control" id="name" name="quantity"
                            placeholder="Quantity">
                    </div>
                    <div class="form-group">
                        <label for="exampleInputEmail1">Per Unit Purchase Price <small
                                class="text-info">[Taka]</small></label>
                        <input x-model.number="purchase_price" type="number" class="form-control" id="name"
                            name="purchase_price" placeholder="Per Unit Purchase Price">
                    </div>
                    <div class="form-group">
                        <label for="exampleInputEmail1">Per Unit Sell Price <small
                                class="text-info">[Taka]</small></label>
                        <input type="number" class="form-control" id="name" name="sell_price"
                            placeholder="Per Unit Sell Price">
                    </div>

                    <button type="submit" class="btn  btn-primary">Add Batch</button>
                </div>
            </div>
        </div>
        <div class="col-4">
            <div class="card">
                <div class="card-header">
                    <h5>-</h5>
                </div>
                <div class="card-body">
                    <div class="form-group">
                        <label for="supplier">Supplier</label>
                        <select class="form-control js-examples-basic-multiple" name="supplier_id" id="supplier">
                            <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($supplier->id); ?>"><?php echo e($supplier->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="exampleInputEmail1">Total Purchase Cost <small
                                class="text-info">[Taka]</small></label>
                        <input type="number" class="form-control" id="name" name="total_purchase_cost"
                            placeholder="Total Purchase Cost" x-model="total_purchase_cost">
                    </div>
                    <div class="form-group">
                        <label for="status">Payment Status:</label>
                        <select name="status" id="status" class="form-control" x-model="status"
                            x-on:change="paid = (status === 'paid' || status ==='due') ? true : false, paid_amount = (status === 'paid') ? total_purchase_cost : 0">
                            <option disabled value="">Payment Status</option>
                            <?php $__currentLoopData = ['paid', 'partial', 'due']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($option); ?>"><?php echo e(ucfirst($option)); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="exampleInputEmail1">Paid Amount <small class="text-info">[Taka]</small></label>
                        <input type="number" class="form-control" id="name" placeholder="Paid Amount"
                            x-bind:disabled="paid" x-model.number="paid_amount">
                    </div>
                    <div class="form-group">
                        <label for="exampleInputEmail1">Due Amount <small class="text-info">[Taka]</small></label>
                        <input type="number" class="form-control" id="due_amount" name="due_amount"
                            placeholder="Due Amount" x-bind:readonly="paid" x-model.number="due_amount" required>
                    </div>
                </div>
            </div>
        </div>
</form>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="./script.js"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

<script>
    $(document).ready(function() {
        $('#products').select2({
            placeholder: "Select a product.",
        });

        $('#supplier').select2({
        placeholder: "Select a supplier.",
        });
    });
</script>

<script>
    <?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\s-pos\resources\views/batches/create.blade.php ENDPATH**/ ?>