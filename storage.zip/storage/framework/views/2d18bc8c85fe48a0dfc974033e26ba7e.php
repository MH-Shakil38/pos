<?php $__env->startSection('title', 'Add a new product'); ?>

<?php $__env->startPush('css'); ?>
    <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/Dropify/0.2.2/css/dropify.min.css'>
<?php $__env->stopPush(); ?>


<?php $__env->startSection('main'); ?>
    <form method="POST" action="<?php echo e(route('setting.update', 1)); ?>" enctype="multipart/form-data">
        <?php echo method_field('PUT'); ?>
        <?php echo csrf_field(); ?>
        <div class="row">
            <div class="col-8">
                <div class="card">
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                    <div class="card-header">
                        <h5>Edit Setting</h5>
                    </div>
                    <div class="card-body">
                        <div class="form-group">
                            <label for="exampleInputEmail1">Shop Name</label>
                            <input type="text" class="form-control" id="name" name="shop_name"
                                value="<?php echo e($settings->shop_name); ?>">
                        </div>
                        <button type="submit" class="btn  btn-primary">Update</button>
                    </div>
                </div>
            </div>
            <div class="col-4">
                <div class="card">
                    <div class="card-header">
                        <h5>Logo</h5>
                    </div>
                    <div class="card-body">
                        <div class="form-group">
                            <input type="file" class="dropify form-control" id="image" name="logo"
                                data-max-height="45" data-max-width="140"
                                data-default-file="<?php echo e(asset('storage/logo/' . @$settings->logo)); ?>">
                        </div>
                    </div>
                </div>
            </div>
    </form>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src='https://cdnjs.cloudflare.com/ajax/libs/Dropify/0.2.2/js/dropify.min.js'></script>
    <script src="./script.js"></script>
    <script>
        $(document).ready(function() {
            $('.dropify').dropify();
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\s-pos\resources\views/setting/index.blade.php ENDPATH**/ ?>