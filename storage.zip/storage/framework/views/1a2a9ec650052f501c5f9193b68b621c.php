<?php $__env->startSection('title', 'Create A New Type'); ?>

<?php $__env->startPush('css'); ?>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('main'); ?>
<form method="POST" action="<?php echo e(route('types.store')); ?>">
    <?php echo csrf_field(); ?>
    <div class="row">
        <div class="col-8">
            <div class="card">
                <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <?php endif; ?>
                <div class="card-header">
                    <h5>Add a new category</h5>
                </div>
                <div class="card-body">
                    <div class="form-group">
                        <label for="exampleInputEmail1">Name</label>
                        <input type="text" class="form-control" id="name" name="name"
                            placeholder="Name Ex. Food & Coffee">
                    </div>
                    <button type="submit" class="btn  btn-primary">Add Expense Type</button>
                </div>
            </div>
        </div>
        <div class="col-4">

        </div>
</form>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\s-pos\resources\views/expenses/types/create.blade.php ENDPATH**/ ?>