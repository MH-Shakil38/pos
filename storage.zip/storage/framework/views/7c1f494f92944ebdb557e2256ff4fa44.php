<?php $__env->startSection('title','Edit batch <?php echo e($batch->batch_no); ?>'); ?>

<?php $__env->startPush('css'); ?>
<script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
<style>
    table tr th,
    td {
        padding: 5px;
    }
</style>
<?php $__env->stopPush(); ?>


<?php $__env->startSection('main'); ?>

<?php if($type == 'adjust_payment'): ?>

<form method="POST" action="<?php echo e(url('batches/'.$batch->id.'?type=adjust_payment')); ?>">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <div class="row" x-effect="total_purchase_cost = (quantity * purchase_price) + <?php echo e($batch->total_purchase_cost); ?>"
        x-data="{ 
        total_purchase_cost: <?php echo e($batch->total_purchase_cost); ?>,
        status: '<?php echo e($batch->status); ?>',
        paid: false,
        payable_amount: 0,
        due_amount: <?php echo e($batch->due_amount); ?>,
    }">
        <div class="col-8">
            <div class="card">
                <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <?php endif; ?>
                <div class="card-header">
                    <h5>Ajust Payment: <span class="badge badge-info"><?php echo e($batch->batch_no); ?></span></h5>
                </div>
                <div class="card-body">
                    <div class="form-group">
                        <label for="status">Payment Status:</label>
                        <select name="status" id="status" class="form-control" x-model="status"
                            x-on:change="paid = (status === 'paid' || status ==='due') ? true : false, due_amount = (status === 'paid') ? 0 : <?php echo e($batch->due_amount); ?>, payable_amount = (status === 'paid') ? <?php echo e($batch->due_amount); ?> : '' ">
                            <option disabled value="">Payment Status</option>
                            <?php $__currentLoopData = ['paid', 'partial']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($option); ?>"><?php echo e(ucfirst($option)); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="paid_amount">Payable Amount <small class="text-info">[Taka]</small></label>
                        <input type="number" class="form-control" id="paid_amount" placeholder="Paid Amount"
                            x-bind:disabled="paid" x-model.number="payable_amount"
                            x-on:keyup="due_amount = <?php echo e($batch->due_amount); ?> - payable_amount"
                            max="<?php echo e($batch->due_amount); ?>">

                        <input type="hidden" name="due_amount" x-model.number="due_amount">
                    </div>
                    <h6 class="text-info">Due Amount: <span class="text-danger" x-text="due_amount"></span> taka</h6>
                    <button type="submit" class="btn  btn-primary">Adjust Payment</button>
                </div>
            </div>
        </div>
        <div class="col-4">
            <div class="card">
                <div class="card-header">
                    <h5>Batch <span class="badge badge-info"><?php echo e($batch->batch_no); ?></span> Details:</h5>
                </div>
                <div class="card-body">
                    <table>
                        <tr>
                            <th>Product</th>
                            <td>:</td>
                            <td><?php echo e($batch->product->name); ?></td>
                        </tr>
                        <tr>
                            <th>Quantity</th>
                            <td>:</td>
                            <td><?php echo e($batch->quantity); ?></td>
                            <td class="text-info">box</td>
                        </tr>
                        <tr>
                            <th>Unit Price</th>
                            <td>:</td>
                            <td><?php echo e($batch->purchase_price); ?></td>
                            <td class="text-info">taka</td>
                        </tr>
                        <tr>
                            <th>Status</th>
                            <td>:</td>
                            <td><?php echo e(ucfirst($batch->status)); ?></td>
                            <td class="text-info">--</td>
                        </tr>
                        <tr class="text-info">
                            <th>Total Amount</th>
                            <td>:</td>
                            <td><?php echo e($batch->total_purchase_cost); ?></td>
                            <td class="text-info">taka</td>
                        </tr>
                        <tr class="text-success">
                            <th>Paid Amount</th>
                            <td>:</td>
                            <td><?php echo e($batch->total_purchase_cost - $batch->due_amount); ?></td>
                            <td class="text-info">taka</td>
                        </tr>
                        <tr class="text-danger">
                            <th>Due Amount</th>
                            <td>:</td>
                            <td><?php echo e($batch->due_amount); ?></td>
                            <td class="text-info">taka</td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>
</form>
</div>
<?php else: ?>

<form method="POST" action="<?php echo e(route('batches.update',$batch->id)); ?>">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <div class="row"
        x-effect="total_purchase_cost = quantity * purchase_price, due_amount = total_purchase_cost - paid_amount"
        x-data="{ 
        quantity: 0, 
        purchase_price: <?php echo e($batch->purchase_price); ?>, 
        total_purchase_cost: 0,
        status: '',
        paid: false,
        paid_amount: 0,
        due_amount: 0,
        isGreaterThanZero(pvalue){
            if(pvalue > 0){
                return true;
            }else{
                return false;
            }
        }
    }
    ">
        <div class="col-8">
            <div class="card">
                <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <?php endif; ?>
                <div class="card-header">
                    <h5>Edit Batch <span class="badge badge-info"><?php echo e($batch->batch_no); ?></span></h5>
                </div>
                <div class="card-body">
                    <div class="form-group">
                        <label for="exampleInputEmail1">Quantity <small class="text-info">[Piece]</small></label>
                        <input x-model.number="quantity" type="number" class="form-control" id="name" name="quantity"
                            placeholder="Quantity">
                    </div>
                    <div class="form-group">
                        <label for="exampleInputEmail1">Per Unit Purchase Price <small
                                class="text-info">[Taka]</small></label>
                        <input x-model.number="purchase_price" type="number" class="form-control" id="name"
                            name="purchase_price" value="<?php echo e($batch->purchase_price); ?>" disabled>
                    </div>

                    <div class="form-group">
                        <label for="name">Total Purchase Cost <small class="text-info">[Taka]</small></label>
                        <input type="number" class="form-control" id="name" name="total_purchase_cost"
                            placeholder="Total Purchase Cost" x-model="total_purchase_cost">
                    </div>
                    <div class="form-group">
                        <label for="status">Payment Status:</label>
                        <select name="status" id="status" class="form-control" x-model="status"
                            x-on:change="paid = (status === 'paid' || status ==='due') ? true : false, paid_amount = (status === 'paid') ? total_purchase_cost : 0">
                            <option disabled value="">Payment Status</option>
                            <?php $__currentLoopData = ['paid', 'partial', 'due']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($option); ?>"><?php echo e(ucfirst($option)); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="paid_amount">Paid Amount <small class="text-info">[Taka]</small></label>
                        <input type="number" class="form-control" id="paid_amount" placeholder="Paid Amount"
                            x-bind:disabled="paid" x-model.number="paid_amount"
                            x-on:keyup="due_amount = total_purchase_cost - paid_amount"
                            x-on:change="due_amount = total_purchase_cost - paid_amount">
                    </div>
                    <div class="form-group">
                        <label for="due_amount">Due Amount <small class="text-info">[Taka]</small></label>
                        <input type="number" class="form-control" id="due_amount" name="due_amount"
                            placeholder="Due Amount" x-bind:disabled="paid" x-model.number="due_amount"
                            x-on:keyup="paid_amount = total_purchase_cost - due_amount"
                            x-on:change="paid_amount = total_purchase_cost - due_amount">
                    </div>

                    <button type="submit" class="btn  btn-primary">Edit Batch</button>
                </div>
            </div>
        </div>
        <div class="col-4">
            <div class="card">
                <div class="card-header">
                    <h5>Batch <span class="badge badge-info"><?php echo e($batch->batch_no); ?></span> Details:</h5>
                </div>
                <div class="card-body">
                    <table>
                        <tr>
                            <th>Product</th>
                            <td>:</td>
                            <td><?php echo e($batch->product->name); ?></td>
                        </tr>
                        <tr>
                            <th>Quantity</th>
                            <td>:</td>
                            <td><?php echo e($batch->quantity); ?> <span class="text-success" x-show="isGreaterThanZero(quantity)">
                                    +
                                    <span x-text="quantity"></span></span></td>
                            <td class="text-info">box</td>
                        </tr>
                        <tr>
                            <th>Unit Price</th>
                            <td>:</td>
                            <td><?php echo e($batch->purchase_price); ?></td>
                            <td class="text-info">taka</td>
                        </tr>
                        <tr>
                            <th>Status</th>
                            <td>:</td>
                            <td><?php echo e(ucfirst($batch->status)); ?></td>
                            <td class="text-info">--</td>
                        </tr>
                        <tr>
                            <th>Total</th>
                            <td>:</td>
                            <td><?php echo e($batch->total_purchase_cost); ?>

                                <span class="text-info" x-show="isGreaterThanZero(total_purchase_cost)"> + <span
                                        x-text="total_purchase_cost"></span></span>
                            </td>
                            <td class="text-info">taka</td>
                        </tr>
                        <tr>
                            <th>Paid</th>
                            <td>:</td>
                            <td><?php echo e($batch->total_purchase_cost - $batch->due_amount); ?> <span class="text-info"
                                    x-show="isGreaterThanZero(paid_amount)"> + <span x-text="paid_amount"></span></span>
                            </td>
                            <td class="text-info">taka</td>
                        </tr>
                        <tr>
                            <th>Due</th>
                            <td>:</td>
                            <td width="250"><?php echo e($batch->due_amount); ?> <span class="text-danger"
                                    x-show="isGreaterThanZero(due_amount)">
                                    + <span x-text="due_amount"></span></span></td>
                            <td class="text-info">taka</td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>
    </div>
</form>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\s-pos\resources\views/batches/edit.blade.php ENDPATH**/ ?>